import React, { useState } from "react";

const AddTopic = () => {
  const [topicTitle, setTopicTitle] = useState("");
  const [topicDesc, setTopicDesc] = useState("");
  const [topicImg, setTopicImg] = useState("");
  const [topicLib, setTopicLib] = useState("");

  const notify = () => toast.error("Empty");

  const handleClick = () => {
    if (
      !topicTitle.trim() ||
      !topicDesc.trim() ||
      !topicImg.trim() ||
      !topicLib.trim()
    ) {
    }
  };

  return <div></div>;
};

export default AddTopic;
